﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Globalization;

namespace WindowsFormsApplication1
    {
    public partial class Form1 : Form
        {

        public Form1 ()
            {
            InitializeComponent();
            InitForm();
            _syncContext = SynchronizationContext.Current;
            CheckUacState();
            GetVaultServices();
            
            
            }

        private void InitForm ()
            {
            System.Resources.ResourceManager resources = new
            System.Resources.ResourceManager( typeof( Form1 ) );
            dataGridView1.Columns.Add( "serviceName", resources.GetString("serviceHeader1" ));
            dataGridView1.Columns.Add( "serviceState", resources.GetString( "serviceHeader2" ) );
            dataGridView1.Columns.Add( "serviceMachine", resources.GetString( "serviceHeader3" ) );
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.AllowUserToAddRows = false;
            }

        private void CheckUacState ()
            {
            if (!GetRegUacState())
                { button5.Text = "UAC is OFF";

                button5.Enabled = false; 
                button5.Refresh();
                }
            else { button5.Text = "UAC is ON. Click to disable";
            button5.Refresh();
            };
            }


        private void SetRegUacState ( bool state )
            {

            Registry.SetValue( @"HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\policies\system", "EnableLUA", Convert.ToInt32( state ) );
            }

        private bool GetRegUacState ()
            {

            RegistryKey key = Registry.LocalMachine.OpenSubKey( @"Software\Microsoft\Windows\CurrentVersion\policies\system", false );

            
                // get value
            object value = key.GetValue( "EnableLUA", -1, RegistryValueOptions.None );
            return Convert.ToBoolean( value );

            }

        private void button2_Click ( object sender, EventArgs e )
            {
            ReRegisterASPFilters();
            }

        private void ReRegisterASPFilters ()
            {
            
            try
                {
                Process first = Process.Start( @"c:\windows\microsoft.net\framework\v4.0.30319\aspnet_regiis.exe", "-i -enable" );
                first.WaitForExit();
                Process second = Process.Start( @"c:\windows\microsoft.net\framework64\v4.0.30319\aspnet_regiis.exe", "-i -enable" );
                second.WaitForExit();
                }
            catch
                {
                MessageBox.Show( "Smth. wrong" );
                }
            finally
                {
                MessageBox.Show( "Done!" );
                }
            }


        public SynchronizationContext _syncContext { get; set; }

        private void button3_Click ( object sender, EventArgs e )
            {
            InstallIIS();
            }

        private void InstallIIS ()
            {
            try
                {
                //string cmdargument = @"/FeatureName:IIS-WebServerRole";
                string cmdargument = @"/FeatureName:IIS-WebServerRole /FeatureName:IIS-ASP /FeatureName:IIS-Metabase /FeatureName:IIS-IIS6ManagementCompatibility /FeatureName:IIS-ManagementConsole /FeatureName:IIS-NetFxExtensibility /FeatureName:IIS-ISAPIExtensions /FeatureName:IIS-ISAPIFilter /FeatureName:IIS-DefaultDocument /FeatureName:IIS-DirectoryBrowsing /FeatureName:IIS-HttpErrors /FeatureName:IIS-StaticContent /FeatureName:IIS-HttpLogging /FeatureName:IIS-RequestMonitor /FeatureName:IIS-HttpCompressionStatic /FeatureName:IIS-RequestFiltering /FeatureName:WAS-WindowsActivationService /FeatureName:WAS-ProcessModel /FeatureName:WAS-NetFxEnvironment /FeatureName:WAS-ConfigurationAPI";

                Process proc = Process.Start( Environment.GetEnvironmentVariable("windir")+"\\SysNative\\dism.exe", @"/Online /Enable-Feature " + cmdargument );
                proc.WaitForExit();
                proc.Close();
                
                }
            catch
                {
                MessageBox.Show( "Smth. wrong" );
                }
            finally
                {
                MessageBox.Show( "Done!" );
                }
            }

        

        private void GetVaultServices ()
            {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            string machine= serverBox.Text;
            string[] services = new string[3] { "IISADMIN", "MSSQL$AUTODESKVAULT", "Autodesk Data Management Job Dispatch" };
            string ret;
            foreach (string service in services)
                {
                try
                    {
                    ServiceController sc = new ServiceController( service, machine);
                    ret = sc.Status.ToString();
                    }
                catch (Exception e)
                    {
                    
                    ret = e.Message.ToString();
                    }
                
                dataGridView1.Rows.Add( service, ret, machine );
                }
            }

        private void RestartVaultServices ()
            {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            string machine = serverBox.Text;
            double timeoutMilliseconds = 5000;
            string[] services = new string[3] { "IISADMIN", "MSSQL$AUTODESKVAULT", "Autodesk Data Management Job Dispatch" };
            string ret;
            foreach (string service in services)
                {
                try
                    {
                    ServiceController sc = new ServiceController( service, machine );
                    ret = sc.Status.ToString() ;
                    try
                        {
                        
                        TimeSpan timeout = TimeSpan.FromMilliseconds( timeoutMilliseconds );
                        dataGridView1.Rows.Add( service, "Stopping service...", machine );
                        dataGridView1.Refresh();
                        sc.Stop();
                        sc.WaitForStatus( ServiceControllerStatus.Stopped, timeout );
                        }
                    catch (Exception e)
                        {
                        ret = e.Message.ToString();
                        }
                    }
                catch (Exception e)
                    {
                    ret = e.Message.ToString();
                    }
                
                dataGridView1.Rows.Add( service, ret, machine );
                dataGridView1.Refresh();
                }
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            foreach (string service in services)
                {
                try
                    {
                    ServiceController sc = new ServiceController( service, machine );
                    ret = sc.Status.ToString();
                    try
                        {
                        TimeSpan timeout = TimeSpan.FromMilliseconds( timeoutMilliseconds );
                        dataGridView1.Rows.Add( service, "Starting service..." );
                        dataGridView1.Refresh();
                        sc.Start();
                        sc.WaitForStatus( ServiceControllerStatus.Running, timeout );
                        }
                    catch (Exception e)
                        {
                        ret = e.Message.ToString();
                        }
                    }
                catch (Exception e)
                    {
                    ret = e.Message.ToString();
                    }
                dataGridView1.Rows.Add( service, ret, machine );
                dataGridView1.Refresh();
                }
            
            GetVaultServices();
            }

        private void button1_Click ( object sender, EventArgs e )
            {
            GetVaultServices();
            }

        private void button4_Click ( object sender, EventArgs e )
            {
            RestartVaultServices();
            }

        private void button5_Click ( object sender, EventArgs e )
            {
            SetRegUacState( false );
            CheckUacState();
            }

        private void Form1_Load ( object sender, EventArgs e )
            {

            }

        //private void comboBox1_SelectedIndexChanged ( object sender, EventArgs e )
        //    {
        //    Thread.CurrentThread.CurrentUICulture = new CultureInfo( comboBox1.SelectedText );
        //    ReloadControlString();
            
        //    }

        //private void ReloadControlString ()
        //    {
        //    System.Resources.ResourceManager resources = new
        //    System.Resources.ResourceManager( typeof( Form1 ) );
        //    this.label1.Name = resources.GetString("label1.Text");
            
        //    }
        }
    }
